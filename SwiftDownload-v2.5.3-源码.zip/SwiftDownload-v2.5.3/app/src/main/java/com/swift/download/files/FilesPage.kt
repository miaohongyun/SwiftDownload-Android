package com.swift.download.files

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.swift.download.Format
import com.swift.download.MediaTypes
import com.swift.download.OpenFileReceiver
import com.swift.download.StorageRoots
import com.swift.download.ui.Ui
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v2.0 新增：文件页 —— 浏览公共下载目录（Download/ 及 BT 子目录）。
 * v2.2 升级：
 *  - 排序（时间/名称/大小 × 升降，记忆选择）
 *  - 文件类型彩色图标 + 体积合计
 *  - 长按菜单：打开 / 分享 / 投屏播放（视频）/ 重命名 / 删除
 */
@SuppressLint("ViewConstructor")
class FilesPage(
    context: Context,
    private val onCast: (path: String) -> Unit = {}
) : FrameLayout(context) {

    /**
     * v2.5：扫描根目录。
     * 优先扫描实际使用的下载根目录（与下载任务落盘位置一致），
     * 同时也扫公共下载目录 —— 用户可能同时存在历史文件与降级后的新文件。
     */
    private val rootDir: File = StorageRoots.downloadRoot(context)
    private val extraRoots: List<File> =
        listOf(StorageRoots.publicDownloads()).filter { it.absolutePath != rootDir.absolutePath }
    private val adapter = FileAdapter()
    private val tvPath: TextView
    private val tvSort: TextView
    private var sortMode = FileSorts.Mode.TIME_DESC
    private val prefs = context.getSharedPreferences("swift_files", Context.MODE_PRIVATE)

    init {
        sortMode = FileSorts.Mode.fromName(prefs.getString("sort", null))
        setBackgroundColor(Ui.BG)
        val root = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(context, 14f), Ui.dp(context, 10f), Ui.dp(context, 14f), Ui.dp(context, 4f))
        }
        val title = Ui.text(context, "文件", 20f, Ui.TXT, bold = true)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tvSort = Ui.text(context, "", 13f, Ui.BLUE)
        tvSort.setOnClickListener { showSortDialog() }
        header.addView(tvSort)
        root.addView(header)

        tvPath = Ui.text(context, "", 12f, Ui.TXT_SUB)
        root.addView(tvPath, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(Ui.dp(context, 14f), 0, Ui.dp(context, 14f), Ui.dp(context, 4f))
        })

        val rv = Ui.recyclerView(context)
        rv.adapter = adapter
        root.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }

    /** 文件扫描放后台线程，避免文件多时切到「文件」页卡顿；用序号丢弃过期结果 */
    @Volatile private var refreshSeq = 0

    fun refresh() {
        val seq = ++refreshSeq
        Thread {
            val seen = HashSet<String>()
            val files = ArrayList<File>()
            for (root in listOf(rootDir) + extraRoots) {
                for (f in listAll(root, 0)) {
                    if (seen.add(f.absolutePath)) files.add(f)
                }
            }
            val sorted = files.sortedWith(FileSorts.comparator(sortMode))
            val total = sorted.sumOf { it.length() }
            post {
                if (seq != refreshSeq) return@post
                adapter.submit(sorted)
                tvSort.text = "排序 · ${sortMode.label} ▾"
                tvPath.text = "下载目录及子目录 · ${sorted.size} 个文件 · 合计 ${Format.bytes(total)}"
            }
        }.apply { isDaemon = true }.start()
    }

    /**
     * 递归扫描下载目录。
     * v2.5：原实现固定 depth=0 且只在 depth<2 时递归 —— 开启"文件自动分类"后
     * 文件落在 Download/视频/xxx/ 这类更深层目录里，文件页就看不到它们。
     * 现在按固定最大深度扫描，保证分类目录下的文件也能列出。
     */
    private fun listAll(dir: File, depth: Int): List<File> {
        val out = ArrayList<File>()
        val subs = dir.listFiles() ?: return out
        for (f in subs) {
            if (f.isDirectory) {
                if (depth < MAX_DEPTH) out.addAll(listAll(f, depth + 1))
            } else if (!f.name.endsWith(".part") && !f.name.endsWith(".swiftprog") &&
                !f.name.endsWith(".m3u8state") && !f.name.endsWith(".tmp")
            ) {
                out.add(f)
            }
        }
        return out
    }

    /* ---------------- 排序选择 ---------------- */

    private fun showSortDialog() {
        val labels = FileSorts.Mode.entries.map { it.label }.toTypedArray()
        android.app.AlertDialog.Builder(context)
            .setTitle("文件排序")
            .setSingleChoiceItems(labels, sortMode.ordinal) { d, which ->
                sortMode = FileSorts.Mode.entries[which]
                prefs.edit().putString("sort", sortMode.name).apply()
                refresh()
                d.dismiss()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /* ---------------- 适配器 ---------------- */

    private inner class FileAdapter : RecyclerView.Adapter<FileVh>() {
        private val items = ArrayList<File>()
        fun submit(list: List<File>) {
            val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
                override fun getOldListSize(): Int = items.size
                override fun getNewListSize(): Int = list.size
                override fun areItemsTheSame(oldPos: Int, newPos: Int): Boolean =
                    items[oldPos].absolutePath == list[newPos].absolutePath
                override fun areContentsTheSame(oldPos: Int, newPos: Int): Boolean =
                    items[oldPos].absolutePath == list[newPos].absolutePath &&
                        items[oldPos].length() == list[newPos].length() &&
                        items[oldPos].lastModified() == list[newPos].lastModified()
            })
            items.clear(); items.addAll(list)
            diff.dispatchUpdatesTo(this)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileVh {
            val row = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val card = Ui.card(parent.context)
            row.addView(card)
            return FileVh(row, card)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(h: FileVh, pos: Int) { h.bind(items[pos]) }
    }

    private inner class FileVh(row: View, private val card: LinearLayout) : RecyclerView.ViewHolder(row) {
        @SuppressLint("SetTextI18n")
        fun bind(f: File) {
            val ctx = card.context
            card.removeAllViews()
            Ui.pressable(card)

            val line = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            line.addView(Ui.iconBadge(ctx, glyphOf(f.name), colorOf(f.name)))

            val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val name = Ui.text(ctx, f.name, 15f, Ui.TXT, bold = true)
            name.maxLines = 1
            name.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            mid.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            mid.addView(Ui.text(ctx, "${typeLabel(f)} · ${Format.bytes(f.length())} · ${df.format(Date(f.lastModified()))}", 12f, Ui.TXT_SUB),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = Ui.dp(ctx, 2f)
                })
            line.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(ctx, 10f)
            })
            card.addView(line)

            card.setOnClickListener { open(f) }
            card.setOnLongClickListener { showMenu(f); true }
        }

        private fun open(f: File) {
            context.sendBroadcast(OpenFileReceiver.intentOf(f.absolutePath).setPackage(context.packageName))
        }

        private fun showMenu(f: File) {
            val ctx = card.context
            val opts = ArrayList<Pair<String, () -> Unit>>()
            opts.add("打开" to { open(f) })
            opts.add("分享" to { share(f) })
            if (MediaTypes.isVideoName(f.name)) opts.add("投屏播放" to { onCast(f.absolutePath) })
            opts.add("重命名" to { rename(f) })
            opts.add("删除" to {
                android.app.AlertDialog.Builder(ctx)
                    .setMessage("删除「${f.name}」？此操作不可恢复。")
                    .setPositiveButton("删除") { _, _ -> f.delete(); refresh() }
                    .setNegativeButton("取消", null)
                    .show()
            })
            android.app.AlertDialog.Builder(ctx)
                .setTitle(f.name)
                .setItems(opts.map { it.first }.toTypedArray()) { _, which -> opts[which].second() }
                .setNegativeButton("取消", null)
                .show()
        }

        private fun share(f: File) {
            try {
                val uri: Uri = androidx.core.content.FileProvider.getUriForFile(
                    context, "${context.packageName}.fileprovider", f)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = MediaTypes.mimeOf(f.name)
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(send, "分享 ${f.name}"))
            } catch (e: Exception) {
                Ui.toast(context, "无法分享此文件")
            }
        }

        private fun rename(f: File) {
            val ctx = card.context
            val et = Ui.singleLineEt(ctx, f.name).apply { setSelection(text.length) }
            val wrap = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(Ui.dp(ctx, 20f), Ui.dp(ctx, 8f), Ui.dp(ctx, 20f), 0)
                addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            android.app.AlertDialog.Builder(ctx)
                .setTitle("重命名")
                .setView(wrap)
                .setPositiveButton("确定") { _, _ ->
                    val n = et.text.toString().trim()
                    if (n.isEmpty() || n == f.name) return@setPositiveButton
                    // v2.5.2：文件名必须是纯名字。允许 "../x" 这类输入会把文件移出下载目录，
                    // 之后任务里的 save_path 就指向了一个不存在的位置（打开/投屏全部失败）
                    if (n.contains('/') || n.contains('\\') || n == "." || n == "..") {
                        Ui.toast(ctx, "文件名不能包含路径分隔符")
                        return@setPositiveButton
                    }
                    val target = File(f.parentFile, n)
                    if (target.exists()) {
                        Ui.toast(ctx, "同名文件已存在")
                    } else if (f.renameTo(target)) {
                        // 同步数据库里的落盘路径，否则任务仍指向旧文件名
                        try {
                            com.swift.download.DownloadDatabase.get(ctx)
                                .renameSavePath(f.absolutePath, target.absolutePath)
                        } catch (e: Exception) {
                            android.util.Log.w("FilesPage", "renameSavePath", e)
                        }
                        Ui.toast(ctx, "已重命名为 $n")
                        refresh()
                    } else {
                        Ui.toast(ctx, "重命名失败")
                    }
                }
                .setNegativeButton("取消", null)
                .show()
        }
    }

    companion object {
        /** 扫描最大深度：Download/ → 分类子目录 → BT/种子目录 → 内容目录 */
        private const val MAX_DEPTH = 4

        /** 按扩展名给图标字形（存纯函数供单测参照：主要逻辑在 glyphOf/colorOf） */
        fun glyphOf(name: String): String = when (com.swift.download.MediaTypes.extOf(name)) {
            in MediaTypes.VIDEO_EXTS -> "▶"
            in MediaTypes.AUDIO_EXTS -> "♪"
            "png", "jpg", "jpeg", "gif", "webp", "bmp" -> "图"
            "pdf" -> "PDF"
            "epub", "txt", "mobi" -> "文"
            "zip", "rar", "7z", "tar", "gz" -> "压"
            "apk" -> "APK"
            "torrent" -> "BT"
            else -> "文"
        }

        fun colorOf(name: String): Int = when (com.swift.download.MediaTypes.extOf(name)) {
            in MediaTypes.VIDEO_EXTS -> Ui.ORANGE
            in MediaTypes.AUDIO_EXTS -> Ui.GREEN
            "png", "jpg", "jpeg", "gif", "webp", "bmp" -> 0xFF7C3AED.toInt()
            "pdf", "epub", "txt", "mobi" -> Ui.TXT_SUB
            "zip", "rar", "7z", "tar", "gz" -> 0xFFD97706.toInt()
            "apk" -> Ui.BLUE
            "torrent" -> Ui.GREEN
            else -> Ui.colorOf(name)
        }

        fun typeLabel(f: File): String = when (com.swift.download.MediaTypes.extOf(f.name)) {
            in MediaTypes.VIDEO_EXTS -> "视频"
            in MediaTypes.AUDIO_EXTS -> "音频"
            "png", "jpg", "jpeg", "gif", "webp", "bmp" -> "图片"
            "pdf" -> "PDF 文档"
            "epub", "txt", "mobi" -> "电子书"
            "zip", "rar", "7z", "tar", "gz" -> "压缩包"
            "apk" -> "安装包"
            "torrent" -> "种子"
            else -> "文件"
        }
    }
}
